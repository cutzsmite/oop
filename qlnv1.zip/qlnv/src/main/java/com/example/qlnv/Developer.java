package com.example.qlnv;

public class Developer extends NhanVien {
private int overhours;
private int basesal;

public int getOverhours(){
    return  overhours;
}
public int getBasesal(){
    return basesal;
}
public Developer(int id, String name, String pos, int tel, int basesal, int overhours, int totalsal, String date){
    this.overhours = overhours;
    this.basesal = basesal;
    this.setPos("Developer");
    totalsal = basesal + (overhours * 200000);

}
}
