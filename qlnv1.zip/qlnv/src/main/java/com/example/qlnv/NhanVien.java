package com.example.qlnv;

public class NhanVien {
    private int id;
    private String name;
    private String pos;
    private int tel;
    private int totalsal;
    private String date;

    public NhanVien(int id, String name, String pos, int tel, int totalsal, String date){
        this.id = id;
        this.name = name;
        this.pos = pos;
        this.tel = tel;
        this.totalsal = totalsal;
        this.date = date;
    }
    public NhanVien() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPos() {
        return pos;
    }

    public void setPos(String pos) {
        this.pos = pos;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }

    public int getTotalsal() {
        return totalsal;
    }

    public void setTotalsal(int totalsal) {
        this.totalsal = totalsal;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
