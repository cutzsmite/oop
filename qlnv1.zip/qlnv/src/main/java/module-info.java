module com.example.qlnv {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.qlnv to javafx.fxml;
    exports com.example.qlnv;
}