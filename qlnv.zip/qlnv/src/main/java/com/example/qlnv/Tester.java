package com.example.qlnv;

public class Tester extends NhanVien {
private int errorfound;
private int basesal;

public int getErrorfound(){
return errorfound;
}
public int getBasesal(){
    return basesal;
}
public Tester(int id, String name, String pos, int tel, int basesal, int errorfound, int totalsal, String date){
this.errorfound = errorfound;
this.setPos("Tester");
this.basesal= basesal;
    totalsal = basesal + (errorfound * 20000);
}
}
