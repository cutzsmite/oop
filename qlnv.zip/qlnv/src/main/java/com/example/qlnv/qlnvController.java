package com.example.qlnv;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class qlnvController implements Initializable {
    @FXML private TextField idTextField;

    @FXML private TextField nameTextField;

    @FXML private TextField telTextField;

    @FXML private TextField timeTextField;

    @FXML private TextField basesalTextField;

    @FXML private TextField bonusTextField;


    @FXML private TextField searchTextField;

    @FXML private ComboBox<String> posBox;

    @FXML private TableView<NhanVien> table;

    @FXML private TableColumn<NhanVien, Integer> idCol;

    @FXML private TableColumn<NhanVien, String> nameCol;

    @FXML private TableColumn<NhanVien, String> posCol;

    @FXML private TableColumn<NhanVien, Integer> telCol;

    @FXML private TableColumn<NhanVien, Integer> totalsalCol;

    @FXML private TableColumn<NhanVien, String> dateCol;
    // Generate Data for PosBox
    ObservableList<String> posList = FXCollections.observableArrayList("Tester", "Developer");
    // Set up some data for table
    ObservableList<NhanVien> nvList = FXCollections.observableArrayList(
new NhanVien(1, "Nguyen Van Teu", "Developer", 113, 12000000, "2021-1-1"),
            new NhanVien(2, "Nguyen Van Nich", "Tester", 114, 10000000, "2021-2-1"),
            new NhanVien(3, "Le Van Ga", "Tester", 117, 10000000,"2021-1-1" )
    );
    private Object NhanVien;

    @Override
    public void initialize(URL location, ResourceBundle resource) {
idCol.setCellValueFactory(new PropertyValueFactory<NhanVien, Integer>("id"));
nameCol.setCellValueFactory(new PropertyValueFactory<NhanVien, String>("name"));
posCol.setCellValueFactory(new PropertyValueFactory<NhanVien, String>("pos"));
telCol.setCellValueFactory(new PropertyValueFactory<NhanVien,Integer>("tel"));
totalsalCol.setCellValueFactory(new PropertyValueFactory<NhanVien, Integer>("totalsal"));
dateCol.setCellValueFactory(new PropertyValueFactory<NhanVien,String>("date"));
posBox.setItems(posList);
table.setItems(nvList);
// Set up Listener for search method
    searchTextField.textProperty().addListener(new ChangeListener() {
        @Override
        public void changed(ObservableValue observable, Object exval, Object newval) {
            searchList((String) exval, (String) newval);
    
        }
    });


}
    public void posAction(ActionEvent event ){

    }
    //Search by attributes
    private void searchList(String exval, String newval) {
        ObservableList<NhanVien> filteredList = FXCollections.observableArrayList();
        if (searchTextField == null || (newval.length() < exval.length()) || newval == null ) {
            table.setItems(nvList);
        }else {

            newval = newval.toUpperCase();
            for (NhanVien NhanVien : table.getItems()) {

                String idSearch = String.valueOf(NhanVien.getId());
                String nameSearch = NhanVien.getName();
                String telSearch = String.valueOf(NhanVien.getTel());
                String dateSearch = NhanVien.getDate();
                if (idSearch.toUpperCase().contains(newval) || nameSearch.toUpperCase().contains(newval) || telSearch.toUpperCase().contains(newval) || dateSearch.toUpperCase().contains(newval)) {
                    filteredList.add(NhanVien);
                }
            }

        }
        table.setItems(filteredList);
    }

// Add function

    public  void add(ActionEvent event) {
        NhanVien newNhanVien = new NhanVien();
        newNhanVien.setId(Integer.parseInt(idTextField.getText()));
        newNhanVien.setName(nameTextField.getText());
        newNhanVien.setPos(posBox.getValue());
        newNhanVien.setTel(Integer.parseInt(telTextField.getText()));
        newNhanVien.setDate(timeTextField.getText());
        newNhanVien.setTotalsal(Integer.parseInt(basesalTextField.getText()));
        newNhanVien.setTotalsal(Integer.parseInt(basesalTextField.getText()));
        if(posBox.getValue() == "Developer") {
            newNhanVien.setTotalsal(Integer.parseInt(basesalTextField.getText()) + Integer.parseInt(bonusTextField.getText())*200000);
        }
        if(posBox.getValue() == "Tester") {
            newNhanVien.setTotalsal(Integer.parseInt(basesalTextField.getText()) + Integer.parseInt(bonusTextField.getText())*20000);
        }
        else {
            resetText();
        }

        nvList.add(newNhanVien);
    }
// Delete function
    public void delete(ActionEvent event) {
        NhanVien selected = table.getSelectionModel().getSelectedItem();
        for(NhanVien NhanVien : nvList){
            if(NhanVien == selected){
                nvList.remove(selected);
            }
        }
    }

    public  void edit(ActionEvent event) {
        Alert al = new Alert(Alert.AlertType.INFORMATION);
        al.setTitle("Confirm?");
        al.setHeaderText("EDIT INFORMATION");
        al.setContentText("Do you want to edit this information");
        ButtonType bYes = new ButtonType("Yes", ButtonBar.ButtonData.YES);
        ButtonType bNo = new ButtonType("No", ButtonBar.ButtonData.NO);
        ButtonType bexit = new ButtonType("Exit", ButtonBar.ButtonData.CANCEL_CLOSE);
        al.getButtonTypes().setAll(bYes, bNo, bexit);

        Optional<ButtonType> result = al.showAndWait();
        if (result.get() == bYes) {
            NhanVien select = table.getSelectionModel().getSelectedItem();
            NhanVien newNhanvien = new NhanVien();
            for (NhanVien nhanVien : nvList) {
                if (nhanVien == select) {
                    NhanVien newNhanVien = new NhanVien();
                    newNhanVien.setId(Integer.parseInt(idTextField.getText()));
                    newNhanVien.setName(nameTextField.getText());
                    newNhanVien.setPos((String) posBox.getValue());
                    newNhanVien.setTel((Integer.parseInt(telTextField.getText())));
                    newNhanVien.setDate(timeTextField.getText());
                    newNhanVien.setTotalsal(Integer.parseInt(basesalTextField.getText()));
                    newNhanVien.setTotalsal(Integer.parseInt(bonusTextField.getText()));
                }
            }
            nvList.set(nvList.indexOf(NhanVien), newNhanvien);
        } else {
            resetText();
            Alert al1 = new Alert(Alert.AlertType.INFORMATION);
            al1.setTitle("System");
            al1.setContentText("Successfully Edited!");
            al1.show();
        }
    }


    //Generate resetText method
    private void resetText() {
        idTextField.setText("");
        nameTextField.setText("");
        telTextField.setText("");
        posBox.setValue("");
        basesalTextField.setText("");
        bonusTextField.setText("");
    }



}
