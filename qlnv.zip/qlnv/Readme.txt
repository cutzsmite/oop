JavaJRE: JavaJRE 8 
JavaJDK: JavaJDK 17

used library & installation in Report document

